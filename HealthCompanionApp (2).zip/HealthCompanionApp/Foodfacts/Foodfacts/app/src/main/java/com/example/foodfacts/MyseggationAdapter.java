package com.example.foodfacts;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class MyseggationAdapter extends RecyclerView.Adapter<MyseggationAdapter.ViewHolder>{
    Context context;
    List<Mysegationmodel> mysegationmodelList;

    public MyseggationAdapter(Context context, List<Mysegationmodel> mysegationmodelList) {
        this.context = context;
        this.mysegationmodelList = mysegationmodelList;
    }

    @NonNull
    @Override
    public MyseggationAdapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new MyseggationAdapter.ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.mysegation,parent,false));

    }

    @Override
    public void onBindViewHolder(@NonNull MyseggationAdapter.ViewHolder holder, int position) {
        holder.textView.setText(mysegationmodelList.get(position).getSegation());

    }

    @Override
    public int getItemCount() {
        return mysegationmodelList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView textView;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            textView=itemView.findViewById(R.id.seg_email);
        }
    }
}
