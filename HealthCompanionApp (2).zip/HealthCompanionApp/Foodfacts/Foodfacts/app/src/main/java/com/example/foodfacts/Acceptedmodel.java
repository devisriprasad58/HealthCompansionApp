package com.example.foodfacts;

public class Acceptedmodel {
   String date,medical,segation,targetweight,tell,time,uid,username,weight;

    public Acceptedmodel() {
    }

    public Acceptedmodel(String date, String medical, String segation, String targetweight, String tell, String time, String uid, String username, String weight) {
        this.date = date;
        this.medical = medical;
        this.segation = segation;
        this.targetweight = targetweight;
        this.tell = tell;
        this.time = time;
        this.uid = uid;
        this.username = username;
        this.weight = weight;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getMedical() {
        return medical;
    }

    public void setMedical(String medical) {
        this.medical = medical;
    }

    public String getSegation() {
        return segation;
    }

    public void setSegation(String segation) {
        this.segation = segation;
    }

    public String getTargetweight() {
        return targetweight;
    }

    public void setTargetweight(String targetweight) {
        this.targetweight = targetweight;
    }

    public String getTell() {
        return tell;
    }

    public void setTell(String tell) {
        this.tell = tell;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }
}
