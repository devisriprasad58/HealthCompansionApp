package com.example.foodfacts;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

import com.google.firebase.firestore.DocumentSnapshot;

public class Weight extends AppCompatActivity {

    TextView next,back;
    EditText weight;

    private String[] weightpoint;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_weight);
        next=findViewById(R.id.next);
        back=findViewById(R.id.back);
        weight=findViewById(R.id.weight);
        weightpoint = new String[]{"20","30","40","50","60"};


        weight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                weightupload();
            }
        });



        next.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {

        
        
        String w_ = weight.getText().toString();

        SharedPreferences sharedPreferences = getSharedPreferences("Student", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString("weight",w_);
        editor.apply();

        Intent intent = new Intent(Weight.this, Tell.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(intent);
    }
});

back.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        Intent intent = new Intent(Weight.this, Weight.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
        startActivity(intent);
    }
});


    }

    private void weightupload() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select an Option");
        builder.setItems(weightpoint, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String selectedOption = weightpoint[which];
                weight.setText(selectedOption);
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }
}