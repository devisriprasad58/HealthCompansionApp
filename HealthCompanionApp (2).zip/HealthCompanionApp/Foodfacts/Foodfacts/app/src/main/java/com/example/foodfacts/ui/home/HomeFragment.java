package com.example.foodfacts.ui.home;

import static android.content.Context.MODE_PRIVATE;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.example.foodfacts.Login_Page;
import com.example.foodfacts.MainActivity;
import com.example.foodfacts.R;
import com.example.foodfacts.Segation;
import com.example.foodfacts.databinding.FragmentHomeBinding;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class HomeFragment extends Fragment {
TextView segation,weight,height,tagetweight,medical;
ImageView imageView;

Button segationbtn;


    FirebaseAuth firebaseAuth;


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        View root= inflater.inflate(R.layout.fragment_home, container, false);
        imageView=root.findViewById(R.id.himage);
segation=root.findViewById(R.id.segition);
weight=root.findViewById(R.id.hweight);
height=root.findViewById(R.id.hheight);
tagetweight=root.findViewById(R.id.htargetweight);
medical=root.findViewById(R.id.hmedical);
segationbtn=root.findViewById(R.id.getsegation);


        FirebaseFirestore db = FirebaseFirestore.getInstance();

        firebaseAuth=FirebaseAuth.getInstance();


        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("Student", MODE_PRIVATE);

        String weg_ = sharedPreferences.getString("weight", "");
        String tell_ = sharedPreferences.getString("tell", "");
        String target_ = sharedPreferences.getString("targetweight", "");
        String med_ = sharedPreferences.getString("medical", "");

        weight.setText(weg_);
        tagetweight.setText(target_);
        medical.setText(med_);
        height.setText(tell_);



        int weight = Integer.parseInt(weg_);

        int targetWeight = Integer.parseInt(target_);



        if (weight >= 0 && weight <= 10 && targetWeight >= 0 && targetWeight <= 10) {
            db.collection("Product")
                    .get()
                    .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                        @Override
                        public void onSuccess(QuerySnapshot queryDocumentSnapshots) {
                            for (QueryDocumentSnapshot documentSnapshot : queryDocumentSnapshots) {
                                String uri = documentSnapshot.getString("uri");
                                Picasso.get().load(uri).into(imageView);


                            }
                        }
                    });
            segation.setText("Good Health");
        } else {
            // Proceed with your application logic since the entered values are valid
            // and fall outside the range of 0 to 10 for both weight and height.
        }

        if (weight >= 10 && weight <= 20 && targetWeight >= 10 && targetWeight <= 20) {
            // Display a message informing the user that the entered values are not valid
            // for representing weight and height, and prompt them to enter valid values.
            segation.setText("Wrong Health");
        } else {
            // Proceed with your application logic since the entered values are valid
            // and fall outside the range of 0 to 10 for both weight and height.
        }

        if (weight >= 20 && weight <= 30 && targetWeight >= 20 && targetWeight <= 30) {
            // Display a message informing the user that the entered values are not valid
            // for representing weight and height, and prompt them to enter valid values.
            segation.setText("Best Health");
        } else {
            // Proceed with your application logic since the entered values are valid
            // and fall outside the range of 0 to 10 for both weight and height.
        }




        // Retrieve data from SharedPreferences
       // String namee = sharedPreferences.getString("rollnumber", "");


segationbtn.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        SharedPreferences sharedPreferences = getActivity().getSharedPreferences("Data", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString("weight",weg_);
        editor.putString("tell",tell_);
        editor.putString("targetweight",target_);
        editor.putString("medical",med_);
        editor.apply();


        Intent intent = new Intent(getActivity(), Segation.class);
        startActivity(intent);
        getActivity().finish();





    }
});






        return root;
    }

}