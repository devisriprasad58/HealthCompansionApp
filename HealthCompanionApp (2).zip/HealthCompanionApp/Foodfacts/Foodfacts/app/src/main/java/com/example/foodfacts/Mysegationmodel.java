package com.example.foodfacts;

public class Mysegationmodel {
   String date,segation,time,uid,user;

    public Mysegationmodel() {
    }

    public Mysegationmodel(String date, String segation, String time, String uid, String user) {
        this.date = date;
        this.segation = segation;
        this.time = time;
        this.uid = uid;
        this.user = user;
    }


    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getSegation() {
        return segation;
    }

    public void setSegation(String segation) {
        this.segation = segation;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getUser() {
        return user;
    }

    public void setUser(String user) {
        this.user = user;
    }
}
