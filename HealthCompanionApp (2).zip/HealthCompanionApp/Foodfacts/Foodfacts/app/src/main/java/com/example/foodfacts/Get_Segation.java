package com.example.foodfacts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class Get_Segation extends AppCompatActivity {
TextView user;
EditText segation;
Button submit;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_get_segation);
        user=findViewById(R.id.rrlogin);
        segation=findViewById(R.id.rrname);
        submit=findViewById(R.id.rrregister);

        FirebaseFirestore db = FirebaseFirestore.getInstance();


        SharedPreferences sharedPreferences = getSharedPreferences("your_shared_prefs", MODE_PRIVATE);

        // Retrieve data from SharedPreferences
        String doc = sharedPreferences.getString("username", "");
        user.setText(doc);



        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String saveCurrentDate, saveCurrenttime;
                Calendar calForDate = Calendar.getInstance();


                SimpleDateFormat currentDate = new SimpleDateFormat("MM, dd, yyyy");
                saveCurrentDate = currentDate.format(calForDate.getTime());

                SimpleDateFormat currenttime = new SimpleDateFormat("HH:mm:ss a");
                String str = segation.getText().toString();
                saveCurrenttime = currenttime.format(calForDate.getTime());
                String uuid = UUID.randomUUID().toString();
                Map<String,Object> objectMap = new HashMap<>();

                objectMap.put("date", saveCurrentDate);
                objectMap.put("time", saveCurrenttime);
                objectMap.put("user", doc);
                objectMap.put("segation", str);
                objectMap.put("uid", uuid);

                db.collection("OurSegation").document(uuid)
                        .set(objectMap)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                Toast.makeText(Get_Segation.this, "OK", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(Get_Segation.this, Admin_Dashbord.class);
                                startActivity(intent);
                                finish();

                            }
                        });





            }
        });




    }
}