package com.example.foodfacts;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Tell extends AppCompatActivity {

    TextView next,back;
EditText tell;
    private String[] ttell;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_tell);
        next=findViewById(R.id.next);
        back=findViewById(R.id.back);
        tell=findViewById(R.id.tell);
        ttell = new String[]{"3' 5''", "4' 6''", "5' 7''","6' 8''","7' 9''"};

        tell.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                heightupload();
            }
        });


        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String w_ = tell.getText().toString();

                SharedPreferences sharedPreferences = getSharedPreferences("Student", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();

                editor.putString("tell",w_);
                editor.apply();



                Intent intent = new Intent(Tell.this, Targetweight.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Tell.this, Weight.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
            }
        });

    }

    private void heightupload() {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select an Option");
        builder.setItems(ttell, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String selectedOption = ttell[which];
                tell.setText(selectedOption);
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();


    }
}