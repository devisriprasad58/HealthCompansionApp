package com.example.foodfacts;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Acceptedadapter extends RecyclerView.Adapter<Acceptedadapter.ViewHolder>{
    Context context;
    List<Acceptedmodel> acceptedmodelList;

    public Acceptedadapter(Context context, List<Acceptedmodel> acceptedmodelList) {
        this.context = context;
        this.acceptedmodelList = acceptedmodelList;
    }

    @NonNull
    @Override
    public Acceptedadapter.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        return new ViewHolder(LayoutInflater.from(parent.getContext()).inflate(R.layout.accepted,parent,false));

    }

    @Override
    public void onBindViewHolder(@NonNull Acceptedadapter.ViewHolder holder, int position) {
        holder.name.setText(acceptedmodelList.get(position).getUsername());
        holder.medical.setText(acceptedmodelList.get(position).getMedical());
        holder.segation.setText(acceptedmodelList.get(position).getSegation());
        holder.targetweight.setText(acceptedmodelList.get(position).getTargetweight());
        holder.tell.setText(acceptedmodelList.get(position).getTell());
        holder.weight.setText(acceptedmodelList.get(position).getWeight());


        holder.getsession.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                SharedPreferences sharedPreferences = context.getSharedPreferences("your_shared_prefs", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("username", acceptedmodelList.get(position).getUsername());
                editor.apply();
                Intent intent = new Intent(context, Get_Segation.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                context.startActivity(intent);

            }
        });



    }

    @Override
    public int getItemCount() {
        return acceptedmodelList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {
        TextView date,medical,segation,targetweight,tell,name,weight;

        Button getsession;
        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            date=itemView.findViewById(R.id.accepted_date);
            medical=itemView.findViewById(R.id.accepted_medical);
            segation=itemView.findViewById(R.id.accepted_segiation);
            targetweight=itemView.findViewById(R.id.accepted_targetweight);
            tell=itemView.findViewById(R.id.accepted_tell);
            name=itemView.findViewById(R.id.accepted_name);
            weight=itemView.findViewById(R.id.accepted_weight);
            getsession=itemView.findViewById(R.id.getses);

        }
    }
}
