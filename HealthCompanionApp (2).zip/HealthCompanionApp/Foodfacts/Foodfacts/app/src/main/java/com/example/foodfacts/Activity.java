package com.example.foodfacts;

import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;

public class Activity extends AppCompatActivity {

    TextView next,back;
    CardView litt,lightly,moderately,very;
    TextView little,lightly_,moderately_,very_;
    TextView finalresult;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_);
        next=findViewById(R.id.next);
        back=findViewById(R.id.back);
        litt=findViewById(R.id.little);
        finalresult=findViewById(R.id.hit);
        little=findViewById(R.id.text1);
        lightly=findViewById(R.id.lightly);
        lightly_=findViewById(R.id.text2);
        moderately=findViewById(R.id.moderately);
        moderately_=findViewById(R.id.text3);
        very=findViewById(R.id.very);
        very_=findViewById(R.id.text4);


        very.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                very.setCardBackgroundColor(Color.RED); // Change to your desired color

                // Get value of CardView
                String cardValue = ((TextView) very_.findViewById(R.id.text4)).getText().toString();

                // Set value in a string
                finalresult.setText("" + cardValue);


                SharedPreferences sharedPreferences = getSharedPreferences("Student", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();

                editor.putString("activity",cardValue);
                editor.apply();




            }
        });


   moderately.setOnClickListener(new View.OnClickListener() {
       @Override
       public void onClick(View v) {
           moderately.setCardBackgroundColor(Color.RED); // Change to your desired color

           // Get value of CardView
           String cardValue = ((TextView) moderately_.findViewById(R.id.text3)).getText().toString();

           // Set value in a string
           finalresult.setText("" + cardValue);
           SharedPreferences sharedPreferences = getSharedPreferences("Student", Context.MODE_PRIVATE);
           SharedPreferences.Editor editor = sharedPreferences.edit();

           editor.putString("activity",cardValue);
           editor.apply();
       }
   });

lightly.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {
        lightly.setCardBackgroundColor(Color.RED); // Change to your desired color

        // Get value of CardView
        String cardValue = ((TextView) lightly_.findViewById(R.id.text2)).getText().toString();

        // Set value in a string
        finalresult.setText("" + cardValue);
        SharedPreferences sharedPreferences = getSharedPreferences("Student", Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = sharedPreferences.edit();

        editor.putString("activity",cardValue);
        editor.apply();
    }
});


        litt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                litt.setCardBackgroundColor(Color.RED); // Change to your desired color

                // Get value of CardView
                String cardValue = ((TextView) little.findViewById(R.id.text1)).getText().toString();

                // Set value in a string
                finalresult.setText("Card Value: " + cardValue);
                SharedPreferences sharedPreferences = getSharedPreferences("Student", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();

                editor.putString("activity",cardValue);
                editor.apply();
            }
        });





        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

             /*   String w_ = weight.getText().toString();
                SharedPreferences sharedPreferences = getSharedPreferences("Student", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();
                editor.putString("weight",w_);
                */


                Intent intent = new Intent(Activity.this, MainActivity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
                finish();
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Activity.this, Medical.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
            }
        });
    }
}