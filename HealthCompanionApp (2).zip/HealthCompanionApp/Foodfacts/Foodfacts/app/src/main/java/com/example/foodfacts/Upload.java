package com.example.foodfacts;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.ContentResolver;
import android.content.DialogInterface;
import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.Toast;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class Upload extends AppCompatActivity {
    ImageView uploadPicIV;
    EditText name,time,pm,medical,weight,height,activity;
    private ProgressBar uploadProgressBar;
    final int IMAGE_REQUEST = 71;
    Uri imageLocationPath;
    String id;
    Activity mContext = this;
    StorageReference objectStorageReference;
    FirebaseFirestore objectFirebaseFirestore;
    FirebaseAuth firebaseAuth;
    private String[] options;
    private String[] tell;
    private String[] weightpoint;

    private String[] targetweight;

    private String[] medicalcondition;

    private String[] timepoint;

    private String[] ampmpoint;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_upload);
        options = new String[]{"Little or No Activity", "Lightly Active", "Moderately Active","Very Active"};
        tell = new String[]{"3' 5''", "4' 6''", "5' 7''","6' 8''","7' 9''"};

        weightpoint = new String[]{"20","30","40","50","60"};

        targetweight = new String[]{"20","30","40","50","60"};

        medicalcondition = new String[]{"None","Diabetes","Pre-Diabetes","Cholesterol","Hypertension","PCOS","Thyroid","Physical Injury","Excessive stress/anxiety","Sleep issues","Depression","Anger issues","Loneliness","Relationship stress"};

        timepoint = new String[]{"10:00","11:00","12:00","1:00","2:00"};

        ampmpoint = new String[]{"AM","PM"};



        ///
        time=findViewById(R.id.utime);
        pm=findViewById(R.id.upm);
        medical=findViewById(R.id.umedical);
        weight=findViewById(R.id.uweight);
        height=findViewById(R.id.uheight);
        activity=findViewById(R.id.uactivity);


        time.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
               timeupload();
            }
        });

        pm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                pmupload();
            }
        });

        medical.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                medicalupload();
            }
        });

        weight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
            weightupload();
            }
        });

        height.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                heightupload();
            }
        });

        activity.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                avtivityupload();
            }
        });

        //  uploadPicET = findViewById(R.id.imageNameET);
        uploadPicIV = findViewById(R.id.imageID);
        name=findViewById(R.id.imageName);
        uploadProgressBar = findViewById(R.id.progress_bar);

        objectStorageReference = FirebaseStorage.getInstance().getReference("imageFolder"); // Create folder to Firebase Storage
        objectFirebaseFirestore = FirebaseFirestore.getInstance();
        firebaseAuth=FirebaseAuth.getInstance();
    }

    private void timeupload() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select an Option");
        builder.setItems(timepoint, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String selectedOption = timepoint[which];
                time.setText(selectedOption);
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void pmupload() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select an Option");
        builder.setItems(ampmpoint, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String selectedOption = ampmpoint[which];
                pm.setText(selectedOption);
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void medicalupload() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select an Option");
        builder.setItems(medicalcondition, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String selectedOption = medicalcondition[which];
                medical.setText(selectedOption);
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void weightupload() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select an Option");
        builder.setItems(weightpoint, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String selectedOption = weightpoint[which];
                weight.setText(selectedOption);
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    private void heightupload() {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select an Option");
        builder.setItems(tell, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String selectedOption = tell[which];
                height.setText(selectedOption);
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();


    }

    private void avtivityupload() {

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select an Option");
        builder.setItems(options, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String selectedOption = options[which];
                activity.setText(selectedOption);
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }

    public void selectImage(View view){
        try {
            Intent objectIntent = new Intent();
            objectIntent.setType("image/*");

            objectIntent.setAction(Intent.ACTION_GET_CONTENT);
            startActivityForResult(objectIntent,IMAGE_REQUEST);

        } catch (Exception e){
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        try {
            if (requestCode == IMAGE_REQUEST
                    && resultCode == RESULT_OK
                    && data != null
                    && data.getData() != null){
                imageLocationPath = data.getData();
                Bitmap objectBitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), imageLocationPath);
                uploadPicIV.setImageBitmap(objectBitmap);
            }

        } catch (Exception e){
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    public void uploadImage(View view){
        try {
            if(/*!uploadPicET.getText().toString().isEmpty() && */imageLocationPath != null){
                //String nameOfimage = "." + getExtension(imageLocationPath);
                String nameOfimage = name.getText().toString() + "." + getExtension(imageLocationPath);
                uploadProgressBar.setVisibility(View.VISIBLE);
                uploadProgressBar.setIndeterminate(true);
                final StorageReference imageRef = objectStorageReference.child(nameOfimage);

                UploadTask objectUploadTask = imageRef.putFile(imageLocationPath);

                objectUploadTask.continueWithTask(new Continuation<UploadTask.TaskSnapshot, Task<Uri>>() {
                    @Override
                    public Task<Uri> then(@NonNull Task<UploadTask.TaskSnapshot> task) throws Exception {
                        if(!task.isSuccessful()){

                            throw task.getException();

                        }
                        return imageRef.getDownloadUrl();
                    }
                }).addOnCompleteListener(new OnCompleteListener<Uri>() {
                    @Override
                    public void onComplete(@NonNull Task<Uri> task) {
                        if (task.isSuccessful()){

                            String saveCurrentDate, saveCurrenttime;
                            Calendar calForDate = Calendar.getInstance();


                            SimpleDateFormat currentDate = new SimpleDateFormat("MM, dd, yyyy");
                            saveCurrentDate = currentDate.format(calForDate.getTime());

                            SimpleDateFormat currenttime = new SimpleDateFormat("HH:mm:ss a");

                            String productname = name.getText().toString();
                            String utime = time.getText().toString();
                            String upm = pm.getText().toString();
                            String umedicine = medical.getText().toString();
                            String uweight = weight.getText().toString();
                            String uheight = height.getText().toString();
                            String uactivity = activity.getText().toString();



                            saveCurrenttime = currenttime.format(calForDate.getTime());
                            String uuid = UUID.randomUUID().toString();
                            Map<String,Object> objectMap = new HashMap<>();
                            String docId = objectFirebaseFirestore.collection("data").document().getId();
                            objectMap.put("uri", task.getResult().toString());

                            objectMap.put("productname", productname);
                            objectMap.put("time", utime);
                            objectMap.put("ampm", upm);
                            objectMap.put("medicien", umedicine);
                            objectMap.put("weight", uweight);
                            objectMap.put("height", uheight);
                            objectMap.put("activity", uactivity);

                            objectMap.put("date", saveCurrentDate);
                            objectMap.put("currenttime", saveCurrenttime);
                            objectMap.put("delete","0");
                            objectMap.put("accptedBy","");
                            //  objectMap.put("sendedBy",firebaseAuth.getCurrentUser().getEmail());
                            objectMap.put("docId",uuid);
                            objectMap.put("deley",0);



                            objectFirebaseFirestore.collection("Product").document(uuid)
                                    .set(objectMap)
                                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                                        @Override
                                        public void onSuccess(Void unused) {
                                            uploadProgressBar.setVisibility(View.VISIBLE);
                                            uploadProgressBar.setIndeterminate(false);
                                            uploadProgressBar.setProgress(0);
                                            Toast.makeText(Upload.this, "Upload Sucessfully", Toast.LENGTH_SHORT).show();
                                        }
                                    });
                        } else if (!task.isSuccessful()){
                            Toast.makeText(Upload.this, task.getException().toString(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });


            } else {
                Toast.makeText(this, "Please provide name for image", Toast.LENGTH_SHORT).show();
            }
        } catch (Exception e){
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
    }

    private String getExtension(Uri uri){
        try {
            ContentResolver objectContentResolver = getContentResolver();
            MimeTypeMap objectMimeTypeMap = MimeTypeMap.getSingleton();

            return objectMimeTypeMap.getExtensionFromMimeType(objectContentResolver.getType(uri));

        } catch (Exception e){
            Toast.makeText(this, e.getMessage(), Toast.LENGTH_SHORT).show();
        }
        return null;






    }
}