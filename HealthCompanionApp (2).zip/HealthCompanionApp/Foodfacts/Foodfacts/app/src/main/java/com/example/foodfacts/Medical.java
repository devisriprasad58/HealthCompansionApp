package com.example.foodfacts;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Medical extends AppCompatActivity {
TextView next,back;
EditText medical;
    private String[] medicalcondition;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_medical);
        next=findViewById(R.id.next);
        back=findViewById(R.id.back);
        medical=findViewById(R.id.medical);
        medicalcondition = new String[]{"None","Diabetes","Pre-Diabetes","Cholesterol","Hypertension","PCOS","Thyroid","Physical Injury","Excessive stress/anxiety","Sleep issues","Depression","Anger issues","Loneliness","Relationship stress"};

        medical.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                medicalupload();
            }
        });

        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String w_ = medical.getText().toString();

                SharedPreferences sharedPreferences = getSharedPreferences("Student", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();

                editor.putString("medical",w_);
                editor.apply();


                Intent intent = new Intent(Medical.this, Activity.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Medical.this, Targetweight.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
            }
        });



    }

    private void medicalupload() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select an Option");
        builder.setItems(medicalcondition, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String selectedOption = medicalcondition[which];
                medical.setText(selectedOption);
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }
}