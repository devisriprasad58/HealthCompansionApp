package com.example.foodfacts;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Build;
import android.os.Bundle;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

public class All_Accecpted extends AppCompatActivity {
    public final String CHANNEL_ID = "1";
    RecyclerView recyclerView;
    FirebaseFirestore firebaseFirestore;
    List<Acceptedmodel> acceptedmodelList;
    Acceptedadapter acceptedadapter;

    String name = "Pritee";
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_all_accecpted);

        firebaseFirestore = FirebaseFirestore.getInstance();
        recyclerView = findViewById(R.id.acceptrec);


        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext(), RecyclerView.VERTICAL, false));
        acceptedmodelList = new ArrayList<Acceptedmodel>();
        acceptedadapter = new Acceptedadapter(getApplicationContext(), acceptedmodelList);
        recyclerView.setAdapter(acceptedadapter);





        firebaseFirestore.collection("Segation").get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            @RequiresApi(api = Build.VERSION_CODES.O)
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                for (DocumentSnapshot documentSnapshot:task.getResult().getDocuments()){
                    Acceptedmodel acceptedmodel = documentSnapshot.toObject(Acceptedmodel.class);
                    acceptedmodelList.add(acceptedmodel);
                    acceptedadapter.notifyDataSetChanged();

                }
            }
        });



    }
}