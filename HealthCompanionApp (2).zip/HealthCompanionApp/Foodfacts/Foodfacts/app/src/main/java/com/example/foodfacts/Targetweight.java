package com.example.foodfacts;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class Targetweight extends AppCompatActivity {

    TextView next,back;
EditText targetweight;
    private String[] target;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_targetweight);
        next=findViewById(R.id.next);
        back=findViewById(R.id.back);
        targetweight=findViewById(R.id.targetweight);

        target = new String[]{"20","30","40","50","60"};

        targetweight.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                targett();
            }
        });



        next.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String w_ = targetweight.getText().toString();

                SharedPreferences sharedPreferences = getSharedPreferences("Student", Context.MODE_PRIVATE);
                SharedPreferences.Editor editor = sharedPreferences.edit();

                editor.putString("targetweight",w_);
                editor.apply();


                Intent intent = new Intent(Targetweight.this, Medical.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
            }
        });

        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(Targetweight.this, Tell.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_REORDER_TO_FRONT);
                startActivity(intent);
            }
        });




    }

    private void targett() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Select an Option");
        builder.setItems(target, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialog, int which) {
                String selectedOption = target[which];
                targetweight.setText(selectedOption);
                dialog.dismiss();
            }
        });

        AlertDialog dialog = builder.create();
        dialog.show();
    }
}