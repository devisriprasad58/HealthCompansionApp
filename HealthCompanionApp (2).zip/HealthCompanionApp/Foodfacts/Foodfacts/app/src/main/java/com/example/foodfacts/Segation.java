package com.example.foodfacts;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class Segation extends AppCompatActivity {

EditText name,segation,phone;
    FirebaseAuth firebaseAuth;
   Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_segation);
        name=findViewById(R.id.sname);
        segation=findViewById(R.id.ssegtion);
        phone=findViewById(R.id.snumber);
        button=findViewById(R.id.regregister);
        FirebaseFirestore db = FirebaseFirestore.getInstance();

        firebaseAuth=FirebaseAuth.getInstance();



        SharedPreferences sharedPreferences = getSharedPreferences("Data", MODE_PRIVATE);

        String weg_ = sharedPreferences.getString("weight", "");
        String tell_ = sharedPreferences.getString("tell", "");
        String target_ = sharedPreferences.getString("targetweight", "");
        String med_ = sharedPreferences.getString("medical", "");



        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                String saveCurrentDate, saveCurrenttime;
                Calendar calForDate = Calendar.getInstance();


                SimpleDateFormat currentDate = new SimpleDateFormat("MM, dd, yyyy");
                saveCurrentDate = currentDate.format(calForDate.getTime());

                SimpleDateFormat currenttime = new SimpleDateFormat("HH:mm:ss a");

                saveCurrenttime = currenttime.format(calForDate.getTime());
                String uuid = UUID.randomUUID().toString();
                Map<String,Object> objectMap = new HashMap<>();

                objectMap.put("date", saveCurrentDate);
                objectMap.put("time", saveCurrenttime);
                objectMap.put("username",firebaseAuth.getCurrentUser().getEmail());
                objectMap.put("weight", weg_);
                objectMap.put("tell", tell_);
                objectMap.put("targetweight", target_);
                objectMap.put("medical", med_);
                objectMap.put("segation", "");
                objectMap.put("uid", uuid);

                db.collection("Segation").document(uuid)
                        .set(objectMap)
                        .addOnSuccessListener(new OnSuccessListener<Void>() {
                            @Override
                            public void onSuccess(Void unused) {
                                Toast.makeText(Segation.this, "OK", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(Segation.this, MainActivity.class);
                                startActivity(intent);
                                finish();

                            }
                        });





            }
        });



    }
}